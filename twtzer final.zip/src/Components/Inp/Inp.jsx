import React from 'react'
import "./inp.css"
function Inp() {
  return (
    <div>
        <img src="about_s4_wave.png" className='boldi  ' alt="" />
        
    </div>
  )
}

export default Inp
